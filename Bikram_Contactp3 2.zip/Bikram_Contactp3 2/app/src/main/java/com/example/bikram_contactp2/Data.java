package com.example.bikram_contactp2;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.Cursor;
import android.content.ContentValues;
//Author - Bikram Singh, netid - bss160130
public class Data extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 5;
    public static final String DATABASE_NAME = "contacts.db";
    public static final String ID = "PERSON_ID";
    public static final String FULL_NAME = "FULL_NAME";
    public static final String DATE_OF_BIRTH = "DATE_OF_BIRTH";
    public static final String PHONE_NUMBER = "PHONE_NUMBER";
    public static final String DATE_OF_FIRST_CONTACT = "DATE_OF_FIRST_CONTACT";
    public static final String ADDRESS_LINE_1 = "ADDRESS_LINE_";
    public static final String ADDRESS_LINE_2 = "ADDRESS_LINE_2";
    public static final String CITY = "CITY";
    public static final String STATE = "STATE";
    public static final String ZIP_CODE = "ZIP_CODE";
    public static final String TABLE_NAME = "PERSON";
    private SQLiteDatabase db;

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    ID + " INTEGER PRIMARY KEY," +
                    FULL_NAME + " TEXT," +
                    DATE_OF_BIRTH + " TEXT," +
                    PHONE_NUMBER + " TEXT," +
                    DATE_OF_FIRST_CONTACT + " TEXT," +
                    ADDRESS_LINE_1 + " TEXT," +
                    ADDRESS_LINE_2 + " TEXT," +
                    CITY + " TEXT," +
                    STATE + " TEXT," +
                    ZIP_CODE + " TEXT)"
            ;

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + TABLE_NAME;


    //constructor
    public Data (Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //-------------------------------------ON CREATE AND UPGRADE------------------------------------

    /*
    On create a new table will be created with the ID of the person as the primary key
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    //Author - Bikram Singh, netid - bss160130
    //---------------------------------------------------------------------------------
    public Cursor getListContent() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        return data;

    }

    public Cursor getItemID(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + ID + " FROM " + TABLE_NAME + " WHERE " + FULL_NAME + " = '" + name + "'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    /*
    Query to retrieve date of birth from the selectedID
     */
    public String getBdate(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + DATE_OF_BIRTH+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(DATE_OF_BIRTH)));
        }
        data.close();
        return str;
    }
    public String getAddressLine1(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + ADDRESS_LINE_1+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(ADDRESS_LINE_1)));
        }
        data.close();
        return str;
    }
    public String getAddressLine2(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + ADDRESS_LINE_2+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(ADDRESS_LINE_2)));
        }
        data.close();
        return str;
    }
    public String getCity(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + CITY+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(CITY)));
        }
        data.close();
        return str;
    }
    public String getState(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + STATE+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(STATE)));
        }
        data.close();
        return str;
    }
    public String getZipCode(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + ZIP_CODE+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(ZIP_CODE)));
        }
        data.close();
        return str;
    }

    /*
    Query to retrieve phone number from the selectedID
     */
    public String getpNo(String selectedID){
        db = this.getWritableDatabase();
        String query = "SELECT " + PHONE_NUMBER+ " FROM " + TABLE_NAME + " WHERE " + ID + " = '" + selectedID + "'";
        Cursor data = db.rawQuery(query, null);

        String str = "";
        if (data.moveToFirst()) {
            str = (data.getString(data.getColumnIndex(PHONE_NUMBER)));
        }
        data.close();
        return str;
    }
    // when called, it will add a new row in the TABLE_NAME table and set
    //colums to the assigned values
    public boolean addData(String fullName, String dob, String pNo, String dof,
                           String address_line1, String address_line2, String city,
                           String state, String zipCode) {
        db = this.getWritableDatabase();
        ContentValues val = new ContentValues(); //instance
        val.put(FULL_NAME, fullName);
        val.put(DATE_OF_BIRTH, dob);
        val.put(PHONE_NUMBER, pNo);
        val.put(DATE_OF_FIRST_CONTACT, dof);
        val.put(ADDRESS_LINE_1, address_line1);
        val.put(ADDRESS_LINE_2, address_line2);
        val.put(CITY, city);
        val.put(STATE, state);
        val.put(ZIP_CODE, zipCode);


        long result = db.insert(TABLE_NAME, null, val);
        return (result==-1)?false:true;
    }


    //Author - Bikram Singh, netid - bss160130
//deletes a particular row
public boolean deleteData(String id)
{
     db = this.getWritableDatabase();
    return db.delete(TABLE_NAME, ID + "=" + id, null) > 0;

}

    //Author - Bikram Singh, netid - bss160130
/*
when executed, this function will find the row by id and change all the values in the row
to new values
 */
public boolean updateData(String id, String fullName, String dob, String pNo, String dof,
                          String address_line1, String address_line2, String city,
                          String state, String zipCode){
        db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(FULL_NAME, fullName);
        cv.put(DATE_OF_BIRTH, dob);
        cv.put(PHONE_NUMBER, pNo);
        cv.put(DATE_OF_FIRST_CONTACT, dof);
        cv.put(ADDRESS_LINE_1, address_line1);
        cv.put(ADDRESS_LINE_2, address_line2);
        cv.put(CITY, city);
        cv.put(STATE, state);
        cv.put(ZIP_CODE, zipCode);

        long result = db.update(TABLE_NAME, cv, ID + "=" + id, null);
        return (result==-1)?false:true;
        }


        /*
        called on reinitialization to drop current table and create a new empty table
         */
public void dropTable(){
    db = this.getWritableDatabase();
    db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    db.execSQL(SQL_CREATE_ENTRIES);
}

}




