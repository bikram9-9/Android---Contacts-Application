package com.example.bikram_contactp2;


import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


// Bikram Singh Contact Manager Phase 2, bss160130.

public class MainActivity extends AppCompatActivity  {

    //Db instance
    // Global Variables
    Data db = new Data(this);
    ListView listView;
    ArrayList<String> list  = new ArrayList<>();
    private SensorManager sm;
    private Sensor sensor_accelerometer;
    private float aStart;
    private float aLast;
    private float shake;
    private  View view;
    private Cursor data;
    private ArrayAdapter listAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.list);
         data = db.getListContent();

        //Author - Bikram Singh, netid - bss160130
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String name = adapterView.getItemAtPosition(i).toString();
                Cursor data = db.getItemID(name);           //saving the name item from db to the String data
                int itemID = -1;
                while (data.moveToNext()) {
                    itemID = data.getInt(0);
                }
                if (itemID > -1) {
                    Intent act2 = new Intent(MainActivity.this, second_activity.class);
                    act2.putExtra("firstName", name);
                    act2.putExtra("lastName", name);
                    act2.putExtra("selectedID", itemID);
                    startActivity(act2);
                }
            }
        });

        /*
        initializeData will update the list from the dataBase and display through arrayAdapter
         */
        initializeData();

        //Sensor value initialization
        //Default sensor values
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor_accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sm.registerListener(mSensorListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        aStart = SensorManager.GRAVITY_EARTH;
        aLast = SensorManager.GRAVITY_EARTH;
        shake = 0.00f;

    }



    // Bikram Singh Contact Manager Phase 2, bss160130.
    public void initializeData(){
        db = new Data(this);
        if(data.getCount() != 0){
            while (data.moveToNext()) {
                list.add(data.getString(1));    //adding name from the database
                Collections.sort(list);             //sorting in alphabetical order

                //display the list using Arrayadapter
                 listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
                listView.setAdapter(listAdapter);
            }
        }
    }



    //Author - Bikram Singh, netid - bss160130
    private final SensorEventListener mSensorListener = new SensorEventListener() {
        //-----------------------------------Sensor detection and calculation ------------------------
        @Override
        public void onSensorChanged(SensorEvent se) {

            // x, y, z coordinates for detecting shaking of phone
            float x = se.values[0];
            float y = se.values[1];
            float z = se.values[2];

            // Equation for shakiness detection
            aStart = aLast;
            aStart = (float) Math.sqrt((double) (x * x + y * y + z * z));
            float change = aStart - aLast;


            shake = shake + (.9f * change);
            if (shake > 12) {
                Collections.reverse(list);
                ArrayAdapter<String> adapter = new ArrayAdapter(MainActivity.this, android.R.layout.simple_list_item_1, list);
                listView.setAdapter(adapter);

            }

        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
        }
    };
    @Override
    protected void onResume() {
        super.onResume();
        sm.registerListener(mSensorListener, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);

    }

    @Override
    protected void onPause() {
        sm.unregisterListener(mSensorListener);
        super.onPause();
    }

    //Author - Bikram Singh, netid - bss160130
    //-----------------------------------Action Bar --------------------------------------------
    @Override
    public boolean onCreateOptionsMenu (Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.first_menu, menu);
        return true;
    }


    /*
    The buttons from first_menu.xml will be executed as follows
     */
    @Override
    public boolean onOptionsItemSelected (@NonNull MenuItem item)
    {
        // this will start the contact_details activity
        switch(item.getItemId()){
            case (R.id.add):{
                startSecondActivity();
                break;
            }
            // to import the sample.txt file in res/raw into the databse
            case( R.id.importFile):{
                try {
                    importTextToDatabase(view); // reads each
                } catch (IOException e) {
                    e.printStackTrace();
                }
                break;
        }
        //to drop the current table and create a new one
            case(R.id.reinitialize):{
                db.dropTable();
                finish();
                startActivity(getIntent());

            }
        }

        return true;
    }

    /*
    Author - Bikram Singh, netid - bss160130

    intent to start second acitvity
     */

    public void startSecondActivity() {
        Intent intent = new Intent(this, second_activity.class);
        startActivity(intent);
    }

    /*

     */
    public void importTextToDatabase(View view) throws IOException {
        String string = "";
        StringBuilder stringBuilder = new StringBuilder();
        InputStream is = this.getResources().openRawResource(R.raw.sample);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        //loop through the entire txt file
        while (true) {
            try {
                if ((string = reader.readLine()) == null) break;
            }
            catch (IOException e) {
                e.printStackTrace();
            }

            stringBuilder.append(string).append("\n");
            // splitting txt file by commas and storing in an array
            String[] tokens = stringBuilder.toString().split(",");

            //storing each value of array into variables to add to db
            String name = tokens[0];
            String dob = tokens[1];
            String pNo = tokens[2];
            String dof = tokens[3];
            String address_line1 = tokens[4];
            String address_line2 = tokens[5];
            String city = tokens[6];
            String state = tokens[7];
            String zipCode = tokens[8];

            db.addData(name,dob, pNo, dof, address_line1, address_line2, city, state,zipCode);

            //setting the builder to null so the next line is read
            stringBuilder.setLength(0);


        }
        is.close();
        //lets the adapter know there is change in list
        finish();
        startActivity(getIntent());
    }
}




