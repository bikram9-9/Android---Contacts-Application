package com.example.bikram_contactp2;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ResultReceiver;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {
    //variable declaration
    private GoogleMap mMap;
    String addressVal;
    Address address;
    EditText curr_location, current_latlang, distanceFromCurr, current_address;
    LatLng latLng;
    private static final int REQUEST_CODE_LOCATION_PEMISSION = 1;
    private ResultReceiver resultReceiver;
    Location addressLocation;
    Location currLocation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        resultReceiver = new AddressResultReceiver(new Handler());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        //receive intent from second_activity to display on map
        Bundle extras = getIntent().getExtras();
        addressVal = extras.getString("address");

        List<Address> addressList = null;

        //Bikram Singh - bss160130
        // execute Geocoding if the address is not null
        if (addressVal != null) {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
//            catch exception if the location cannot be GeoCoded
            try {
                addressList = geocoder.getFromLocationName(addressVal, 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            address = addressList.get(0);       // get the address from list
        } else {
            Toast.makeText(this, "Address cannot be empty",
                    Toast.LENGTH_LONG).show();
        }


        //receives the latitude and longitude of entered address
        latLng = new LatLng(address.getLatitude(), address.getLongitude());
         addressLocation = new Location("providerNa");
        addressLocation.setLatitude(address.getLatitude());
        addressLocation.setLongitude(address.getLongitude());

        //Set text to display the address, latitude and longitude on the display
        curr_location = findViewById(R.id.curr_location);
        curr_location.setText(addressVal);
        current_latlang = findViewById(R.id.current_latlang);
        current_latlang.setText(latLng.toString());
        distanceFromCurr = findViewById(R.id.distanceFromCurr);
        current_address = findViewById(R.id.current_address);


        //if the given locations do not give permission request permissions,
        //else get the current location
        if (ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(MapsActivity.this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE_LOCATION_PEMISSION
            );
        } else {
            getCurrentLocaton();
        }
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_LOCATION_PEMISSION && grantResults.length > 0) {
            getCurrentLocaton();
        } else {
            Toast.makeText(this, "NO PERMISSION", Toast.LENGTH_SHORT).show();
        }
    }


    // followed tutorial for reference : https://www.youtube.com/watch?v=ari3iD-3q8c
    private void getCurrentLocaton() {
        LocationRequest locationReqest = new LocationRequest();
        locationReqest.setInterval(10000);
        locationReqest.setFastestInterval(3000);
        locationReqest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

            return;
        }else{
            LocationServices.getFusedLocationProviderClient(MapsActivity.this)
                    .requestLocationUpdates(locationReqest,
                            new LocationCallback() {

                                @Override
                                public void onLocationResult(LocationResult locationResult) {
                                    super.onLocationResult(locationResult);
                                    LocationServices.getFusedLocationProviderClient(MapsActivity.this).removeLocationUpdates(this);
                                    if(locationResult != null && locationResult.getLocations().size() > 0){
                                        int latestLocationIndex = locationResult.getLocations().size() - 1;
                                        double latitude = locationResult.getLocations().get(latestLocationIndex).getLatitude();
                                        double longitude = locationResult.getLocations().get(latestLocationIndex).getLongitude();

                                         currLocation = new Location("providerNa");
                                        currLocation.setLatitude(latitude);
                                        currLocation.setLongitude(longitude);
                                        fetchAddressFromLatLong(currLocation);

                                        //call function to calculate distance between
                                        //entered address and current location
                                        distanceBetweenTwoLocations(currLocation,addressLocation);

                                    }else{
                                        current_address.setText("address not found");
                                    }
                                }


                    }, Looper.getMainLooper());
        }

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //marker will be changed to the entered address
        mMap.addMarker(new MarkerOptions().position(latLng).title(addressVal));
        // to zoom into the location
        mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));

    }



    public void fetchAddressFromLatLong(Location location){
        Intent intent = new Intent(this, FetchAddress.class);
        intent.putExtra(FetchAddress.RECEIVER,resultReceiver);
        intent.putExtra(FetchAddress.LOCATION_DATA_EXTRA,location);
        startService(intent);
    }

    public void distanceBetweenTwoLocations(Location location1, Location location2){
        //calculates distance between address and current location in KiloMeters
        float distance = location1.distanceTo(location2)/1000;
        String result = "Distance: " + distance + " km";
         distanceFromCurr.setText(result);
    }



    // followed tutorial for reference : https://www.youtube.com/watch?v=ari3iD-3q8c
    private class AddressResultReceiver extends ResultReceiver{
        public AddressResultReceiver(Handler handler){
            super(handler);
        }

        @Override
        protected void onReceiveResult(int resultCode, Bundle resultData) {
            super.onReceiveResult(resultCode, resultData);
            if(resultCode == FetchAddress.SUCCESS_RESULT){
                current_address.setText(resultData.getString(FetchAddress.RESULT_DATA_KEY));
            }else{
                Toast.makeText(MapsActivity.this, resultData.getString(FetchAddress.RESULT_DATA_KEY), Toast.LENGTH_SHORT).show();
            }
        }
    }

}