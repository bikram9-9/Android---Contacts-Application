package com.example.bikram_contactp2;
import android.app.IntentService;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.text.TextUtils;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

// followed tutorial for reference : https://www.youtube.com/watch?v=ari3iD-3q8c


public class FetchAddress extends IntentService{
    //declaring constants
    private static final String PACKAGE_NAME = "com.example.bikram_contactp2";
    static final String RESULT_DATA_KEY = PACKAGE_NAME + ".RESULT_DATA_KEY";
    static final String RECEIVER = PACKAGE_NAME + ".RECEIVER";
    static final String LOCATION_DATA_EXTRA = PACKAGE_NAME + ".LOCATION_DATA_EXTRA";
    static final int SUCCESS_RESULT =1;
    static final int FAILURE_RESULT = 0;
    private ResultReceiver resultReceiver;
    Location  location2;

    //constructor
    public FetchAddress() {
        super("com.example.bikram_contactp2.FetchAddress");
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        if(intent != null){
            String errorMessage = " ";
            resultReceiver = intent.getParcelableExtra(RECEIVER);
            location2 = intent.getParcelableExtra(LOCATION_DATA_EXTRA);
            if(location2 == null){
                return;
            }

            /*
            Using Geocoder, we retrieve the longitude and latitude and add it in a
            List of type Address
             */
            Geocoder geocoder= new Geocoder(this, Locale.getDefault());
            List<Address> addresses = null;
            try{
                addresses = geocoder.getFromLocation(location2.getLatitude(),location2.getLongitude(),1);
            }catch(Exception e){
                e.printStackTrace();
            }

            /*
            If address is null, we display an error message
             */
            if(addresses ==  null || addresses.isEmpty()){
                deliverResultToReceiver(FAILURE_RESULT,errorMessage);
            }else{
                Address address = addresses.get(0);
                ArrayList<String> addressFragments = new ArrayList<>();
                for(int i=0; i <= address.getMaxAddressLineIndex(); i++){
                    addressFragments.add(address.getAddressLine(i));
                }
                deliverResultToReceiver(SUCCESS_RESULT, TextUtils.join(Objects.requireNonNull(
                        System.getProperty("line.separator")), addressFragments
                ));
            }
        }
    }

    private void deliverResultToReceiver(int resultCode, String addressMessage){
        Bundle bundle = new Bundle();
        bundle.putString(RESULT_DATA_KEY, addressMessage);
        resultReceiver.send(resultCode, bundle);
    }
}
