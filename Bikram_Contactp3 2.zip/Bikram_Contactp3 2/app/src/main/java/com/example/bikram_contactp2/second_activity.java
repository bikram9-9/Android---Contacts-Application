package com.example.bikram_contactp2;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.view.Menu;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
// Bikram Singh Contact Manager Phase 2, bss160130.
public class second_activity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, View.OnClickListener {

    // Variable Declaration
    private String selectedFirstName;
    private String selectedLastName;
    private int selectedID;
    Data db;
    EditText firstName;
    EditText lastName;
    EditText pNo;// phone number

    EditText bdate; // birth date
    EditText dof;//date of first contact
    EditText city;
    EditText addLine1;
    EditText addLine2;
    EditText state;
    EditText zipCode;
    String address_line1;
    String address_line2;
    String full_address;
    String cityData;
    String stateData;
    String zipData;
    private Button map_button;

    int DATE_DIALOG = 0;
    private SQLiteDatabase database;



    //--------------------------------------------------ON CREATE-----------------------------
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent receivedIntent = getIntent();        // to receive intent
        selectedID = receivedIntent.getIntExtra("selectedID", -1);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_layout);

        //linking map_button to xml and starting onClickListener
         map_button = findViewById(R.id.map_address);
        map_button.setOnClickListener(this);

        //create instance of Data.java for access to database
        db = new Data(this);

        //link the fields from XML to activity
        firstName = findViewById(R.id.fName);
        lastName = findViewById(R.id.lName);
        pNo = findViewById(R.id.pNo);
        bdate = findViewById(R.id.dob);
        dof = findViewById(R.id.dof);
        city = findViewById(R.id.city);
        addLine1 = findViewById(R.id.address_line1);
        addLine2 = findViewById(R.id.address_line2);
        state = findViewById(R.id.state);
        zipCode = findViewById(R.id.zip_code);

        //set all the returned fields from database
        pNo.setText(db.getpNo(Integer.toString(selectedID)));
        bdate.setText(db.getBdate(Integer.toString(selectedID)));
        addLine1.setText(db.getAddressLine1(Integer.toString(selectedID)));
        addLine2.setText(db.getAddressLine2(Integer.toString(selectedID)));
        city.setText(db.getCity(Integer.toString(selectedID)));
        state.setText(db.getState(Integer.toString(selectedID)));
        zipCode.setText(db.getZipCode(Integer.toString(selectedID)));

        //initializes the current date for the date of first contact entry to be the current date
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        String currentTime = sdf.format(new Date());
        dof.setText(currentTime);

        // Call fragment when DOF is clicked
        dof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DATE_DIALOG = 2;
                DialogFragment dateSelector = new DateSelector();
                dateSelector.show(getSupportFragmentManager(), "Date Selector");
            }
        });

        // Call fragment when DOB is clicked
        bdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {       // when date is clicked
                DATE_DIALOG = 1;
                DialogFragment dateSelector = new DateSelector();
                dateSelector.show(getSupportFragmentManager(), "Date Selector");
            }
        });


        selectedFirstName = receivedIntent.getStringExtra("firstName");
        firstName.setText(selectedFirstName);

        selectedLastName = receivedIntent.getStringExtra("lastName");
        lastName.setText(selectedLastName);

    }




        //-------------------------------------INFLATION/ SAVE/DELETE--------------------------
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.second_menu, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            int id = item.getItemId();
            String fName = firstName.getText().toString();
            String lName = lastName.getText().toString();
            String birthDate = bdate.getText().toString();
            String phNo = pNo.getText().toString();
            String dofc = dof.getText().toString();
            String person_id = Integer.toString(selectedID);
             cityData = city.getText().toString();
             stateData = state.getText().toString();
             zipData = zipCode.getText().toString();
            address_line1 = addLine1.getText().toString();
            address_line2 = addLine2.getText().toString();
            full_address = address_line1 + " " + address_line2 + " " +
                    " " + cityData + " " + stateData + " " + zipData;
            /*
            On clicking save, the program must read each input and
            store in the database with the id as the primary key.
             */
            if (id == R.id.save) {
                db.addData(fName + " " + lName, birthDate, phNo, dofc,address_line1,
                        address_line2, cityData, stateData, zipData); // add to DB
            }

             else if (id == R.id.update) {
                    db.updateData(person_id, fName + " " + lName, birthDate, phNo, dofc,
                            address_line1,
                            address_line2, cityData, stateData, zipData);

                } else if (id == R.id.delete) {
                    db.deleteData(person_id);
                Intent intent = new Intent (this, MainActivity.class);
                startActivity(intent);

                }
            Intent intent = new Intent (second_activity.this,MainActivity.class);
            startActivity(intent);   // return to first page
//                return true;
                return super.onOptionsItemSelected(item);

        }

    //----------------------------------To set on Date Select---------------------------------------

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.YEAR, year);


        String currDate = DateFormat.getDateInstance(DateFormat.SHORT).format(calendar.getTime());
        if(DATE_DIALOG == 1)
        {
            bdate.setText(currDate);
        }
        else if (DATE_DIALOG == 2)
        {
            dof.setText(currDate);
        }
    }




    @Override
    public void onClick(View view) {
        cityData = city.getText().toString();
        stateData = state.getText().toString();
        zipData = zipCode.getText().toString();
        address_line1 = addLine1.getText().toString();
        address_line2 = addLine2.getText().toString();
        full_address = address_line1 + " " + address_line2 + " " +
                " " + cityData + " " + stateData + " " + zipData;

        switch (view.getId()) {
            case R.id.map_address:
                Intent intent = new Intent(second_activity.this, MapsActivity.class);
                intent.putExtra("address", full_address);
                startActivity(intent);
        }
    }
}
